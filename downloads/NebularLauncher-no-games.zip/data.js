const myGames = [
    {
        "title": "polytrack",
        "folderName": "polytrack"
    },
    {
        "title": "Flappybird",
        "folderName": "Flappybird"
    }
];