registerGameMeta({ name: "Tic Tac Toe", type: "game" });
