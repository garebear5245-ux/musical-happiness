registerGameMeta({ name: "BrickBox", type: "game" });
