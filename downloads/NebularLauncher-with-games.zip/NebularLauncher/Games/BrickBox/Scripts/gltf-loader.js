"use strict";
/* gltf-loader.js — minimal GLB binary parser, no external dependencies.
   Returns a THREE.Group with static meshes from the first scene.
   Handles position/normal/uv attributes, indices, and PBR base colour. */

async function loadGLB(url){
  let buf;
  if (url.startsWith("data:")){
    const b64 = url.slice(url.indexOf(",") + 1);
    const bin = atob(b64);
    buf = new ArrayBuffer(bin.length);
    const u8 = new Uint8Array(buf);
    for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
  } else {
    const resp = await fetch(url);
    if (!resp.ok) throw new Error("GLB fetch " + resp.status + ": " + url);
    buf = await resp.arrayBuffer();
  }
  const dv = new DataView(buf);
  if (dv.getUint32(0, true) !== 0x46546C67) throw new Error("Not GLB: " + url);

  let jsonChunk = null, binChunk = null, off = 12;
  while (off < buf.byteLength){
    const len  = dv.getUint32(off, true); off += 4;
    const type = dv.getUint32(off, true); off += 4;
    if      (type === 0x4E4F534A) jsonChunk = { start:off, len };
    else if (type === 0x004E4942) binChunk  = { start:off, len };
    off += len;
  }
  if (!jsonChunk) throw new Error("GLB: no JSON chunk");

  const json = JSON.parse(new TextDecoder().decode(new Uint8Array(buf, jsonChunk.start, jsonChunk.len)));
  const bin  = binChunk ? buf : null;
  const binOff = binChunk ? binChunk.start : 0;

  function compSize(ct){ return ct===5120||ct===5121?1:ct===5122||ct===5123?2:4; }
  function compCount(type){ return {SCALAR:1,VEC2:2,VEC3:3,VEC4:4,MAT4:16}[type]||1; }

  function accessor(idx){
    const acc = json.accessors[idx];
    const bv  = json.bufferViews[acc.bufferView];
    const start = binOff + (bv.byteOffset||0) + (acc.byteOffset||0);
    const n = acc.count * compCount(acc.type);
    const cs = compSize(acc.componentType);
    const slice = buf.slice(start, start + n * cs);
    switch(acc.componentType){
      case 5120: return new Int8Array(slice);
      case 5121: return new Uint8Array(slice);
      case 5122: return new Int16Array(slice);
      case 5123: return new Uint16Array(slice);
      case 5125: return new Uint32Array(slice);
      case 5126: return new Float32Array(slice);
    }
  }

  // texture cache: index -> T.Texture (image loads async via ImageBitmap)
  const _texCache = new Map();
  function _getTexture(texIdx){
    if (_texCache.has(texIdx)) return _texCache.get(texIdx);
    const texInfo = json.textures && json.textures[texIdx];
    const tex = new T.Texture();
    tex.flipY = false;   // GLB UV convention (origin bottom-left already flipped)
    if (texInfo != null && json.images){
      const img = json.images[texInfo.source];
      if (img && img.bufferView != null){
        const bv = json.bufferViews[img.bufferView];
        const slice = new Uint8Array(buf, binOff + (bv.byteOffset || 0), bv.byteLength);
        const blob = new Blob([slice], { type: img.mimeType || "image/png" });
        createImageBitmap(blob).then(bmp => { tex.image = bmp; tex.needsUpdate = true; });
      }
    }
    _texCache.set(texIdx, tex);
    return tex;
  }

  function buildNode(ni){
    const nd = json.nodes[ni];
    const grp = new T.Group();
    if (nd.matrix){
      grp.matrix.fromArray(nd.matrix);
      grp.matrix.decompose(grp.position, grp.quaternion, grp.scale);
    } else {
      if (nd.translation) grp.position.fromArray(nd.translation);
      if (nd.rotation)    grp.quaternion.fromArray(nd.rotation);
      if (nd.scale)       grp.scale.fromArray(nd.scale);
    }
    if (nd.mesh != null){
      for (const prim of json.meshes[nd.mesh].primitives){
        const geo = new T.BufferGeometry();
        const A = prim.attributes;
        if (A.POSITION != null){
          const d = accessor(A.POSITION);
          geo.setAttribute("position", new T.BufferAttribute(new Float32Array(d), 3));
        }
        if (A.NORMAL != null){
          const d = accessor(A.NORMAL);
          geo.setAttribute("normal", new T.BufferAttribute(new Float32Array(d), 3));
        }
        if (A.TEXCOORD_0 != null){
          const d = accessor(A.TEXCOORD_0);
          geo.setAttribute("uv", new T.BufferAttribute(new Float32Array(d), 2));
        }
        if (prim.indices != null){
          const d = accessor(prim.indices);
          geo.setIndex(new T.BufferAttribute(d instanceof Uint32Array ? new Uint32Array(d) : new Uint16Array(d), 1));
        }
        if (!A.NORMAL) geo.computeVertexNormals();

        let mat;
        if (prim.material != null && json.materials && json.materials[prim.material]){
          const gm = json.materials[prim.material];
          const pbr = gm.pbrMetallicRoughness || {};
          const bf = pbr.baseColorFactor;
          mat = new T.MeshStandardMaterial({
            color:    bf ? new T.Color(bf[0], bf[1], bf[2]) : new T.Color(0xffffff),
            roughness: pbr.roughnessFactor != null ? pbr.roughnessFactor : 0.5,
            metalness: pbr.metallicFactor  != null ? pbr.metallicFactor  : 0,
          });
          if (pbr.baseColorTexture != null)
            mat.map = _getTexture(pbr.baseColorTexture.index);
          if (gm.normalTexture != null)
            mat.normalMap = _getTexture(gm.normalTexture.index);
          if (pbr.metallicRoughnessTexture != null)
            mat.metalnessMap = mat.roughnessMap = _getTexture(pbr.metallicRoughnessTexture.index);
        } else {
          mat = new T.MeshStandardMaterial({ color:0x888888, roughness:0.5 });
        }

        const mesh = new T.Mesh(geo, mat);
        mesh.castShadow = mesh.receiveShadow = true;
        grp.add(mesh);
      }
    }
    if (nd.children) for (const ci of nd.children) grp.add(buildNode(ci));
    return grp;
  }

  const root = new T.Group();
  const sc = json.scenes ? json.scenes[json.scene||0] : null;
  const nodes = sc ? sc.nodes : (json.nodes ? json.nodes.map((_,i)=>i) : []);
  for (const ni of nodes) root.add(buildNode(ni));
  return root;
}
