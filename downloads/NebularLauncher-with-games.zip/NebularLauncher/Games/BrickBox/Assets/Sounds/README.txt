Drop your .ogg sound files here. The game (gmod.html) looks for exactly these paths:

Assets/Sounds/Footsteps/ConcreteFootsteps.ogg   - loops while walking on the floor/concrete
Assets/Sounds/Footsteps/WoodFootsteps.ogg       - loops while walking on wooden props (Crate, Plank)
Assets/Sounds/Tools/ToolRay/ToolRayuse.ogg       - one-shot when the ToolRay spawns a prop
Assets/Sounds/Tools/GravityRay/open.ogg          - one-shot when the GravityRay grabs a prop
Assets/Sounds/Tools/GravityRay/hold_loop.ogg     - loops while the GravityRay is holding a prop

If a file is missing the game still runs; that sound just stays silent.
Footstep loops should be seamless loops; the game fades them in/out so they stop smoothly.
