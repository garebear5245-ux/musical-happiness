const myGames = [
    {
        "title": "Tic Tac Toe",
        "folderName": "P2PTicTacToe"
    },
    {
        "title": "BrickBox",
        "folderName": "BrickBox"
    }
];
